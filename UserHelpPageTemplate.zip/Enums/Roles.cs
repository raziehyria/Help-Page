﻿namespace Enums
{
    public enum Roles
    {
        Supervisor,
        Admin,
        User
    }
}