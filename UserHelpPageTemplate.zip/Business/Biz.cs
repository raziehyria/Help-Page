﻿using AppLogger;
using AutoMapper;
using DataLayer;
using DataLayer.Entities;
using Microsoft.EntityFrameworkCore;
using ViewModels;

namespace Business
{
    public class Biz : IBiz
    {
        private readonly IRepository _repo;
        private readonly IMapper _mapper;
        private readonly IUserHelpPageLogger _logger;

        public Biz(IRepository repo, IMapper mapper , IUserHelpPageLogger logger)
        {
            this._repo = repo;
            this._mapper = mapper;
            this._logger = logger;
        }
        #region Application
        public async Task<List<ApplicationVM>> GetApps()
        {
            
            var allApps = await _repo.GetApps().Include(x => x.Category).ToListAsync();
            // Mapping Application object to Application VM object Type
            return _mapper.Map<List<Application>, List<ApplicationVM>>(allApps);

        }
        public async Task<ApplicationVM> GetAppById(int id)
        {
            var currentApp = await _repo.GetApps().Include(x=> x.Category).Where(x => x.Id == id).FirstOrDefaultAsync();

            if (currentApp == null)
            {
                throw new AppException("Application not found!");
            }

            return _mapper.Map<Application, ApplicationVM>(currentApp);

        }
        public async Task<List<ApplicationVM>> SearchApps(string keyword)
        {
            var apps = await _repo.GetApps().Where(x => x.Name.Contains(keyword)).ToListAsync();

            return _mapper.Map<List<Application>, List<ApplicationVM>>(apps);
        }
        public async Task<List<ApplicationVM>> GetAppsByCategory(int categoryId)
        {
            // Use your data access method (e.g., Entity Framework) to query the database
            // and retrieve the apps with the specified category.
            // For demonstration purposes, let's assume you have a list of apps and filter it.            
            var filteredApps = await _repo.GetApps().Include(x => x.Category).Where(app => app.CategoryId == categoryId).ToListAsync();
            return _mapper.Map<List<Application>, List<ApplicationVM>>(filteredApps);
        }
        public async Task<int> CreateApp(ApplicationVM appVM)
        {
            var app = _mapper.Map<ApplicationVM, Application>(appVM);
            return await _repo.AddItemAsync(app);
        }
        public async Task<int> UnsafeDeleteApp(int appId)
        {

            var app = await _repo.GetApps().FirstOrDefaultAsync(x => x.Id == appId);

            if (app == null)
            {
                throw new AppException("Application not found!");
            }

            return await _repo.DeleteItemAsync(app);
        }
        public async Task<int> DeleteApp(int appId)
        {

            var app = await _repo.GetApps().FirstOrDefaultAsync(x => x.Id == appId);

            if (app == null)
            {
                throw new AppException("Application not found!");
            } 
            
            app.Cloak = true;

            return await _repo.UpdateItemAsync(app);
        }

        public async Task<int> UpdateApp(ApplicationVM appVM)
        {
            var existingApp = await GetAppById(appVM.Id);
            if (existingApp == null)
            {
                throw new AppException("Application not found!");
            }
            var updatedApp = _mapper.Map<ApplicationVM, Application>(appVM);
            return await _repo.UpdateItemAsync(updatedApp);
        }

        #endregion Application

        #region Category

        public async Task<List<CategoryVM>> GetCategories()
        {            
            var categories = await _repo.GetCategories().ToListAsync();
            // Mapping Application object to Application VM object Type
            return _mapper.Map<List<Category>, List<CategoryVM>>(categories);

        }
        public async Task<CategoryVM> GetCategoryById(int id)
        {
            var currentApp = await _repo.GetCategories().Where(x => x.Id == id).FirstOrDefaultAsync();

            if (currentApp == null)
            {
                throw new AppException("Application not found!");
            }

            return _mapper.Map<Category, CategoryVM>(currentApp);

        }
        public async Task<int> CreateCategory(CategoryVM categoryVM)
        {
            var app = _mapper.Map<CategoryVM, Category>(categoryVM);
            return await _repo.AddItemAsync(app);
        }

        public async Task<int> UnsafeDeleteCategory(int categoryId)
        {

            var app = await _repo.GetCategories().FirstOrDefaultAsync(x => x.Id == categoryId);

            if (app == null)
            {
                throw new AppException("Category not found!");
            }

            return await _repo.DeleteItemAsync(app);
        }
        public async Task<int> DeleteCategory(int categoryId)
        {

            var app = await _repo.GetCategories().FirstOrDefaultAsync(x => x.Id == categoryId);

            if (app == null)
            {
                throw new AppException("Category not found!");
            }

            app.Cloak = true;

            return await _repo.UpdateItemAsync(app);
        }

        public async Task<int> UpdateCategory(CategoryVM categoryVM)
        {
            var existingApp = await _repo.GetCategories()
                .FirstOrDefaultAsync(x => x.Id == categoryVM.Id);
            if (existingApp == null)
            {
                throw new AppException("Application not found!");
            }
            var updatedApp = _mapper.Map<CategoryVM, Category>(categoryVM);
            return await _repo.UpdateItemAsync(updatedApp);
        }
        #endregion Category
    }
}
