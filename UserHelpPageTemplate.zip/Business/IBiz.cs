﻿using ViewModels;

namespace Business
{
    public interface IBiz
    {
        #region Application
        Task<List<ApplicationVM>> GetApps();
        Task<ApplicationVM> GetAppById(int id);
        Task<List<ApplicationVM>> SearchApps(string keyword);
        Task<List<ApplicationVM>> GetAppsByCategory(int categoryId);
        Task<int> CreateApp(ApplicationVM app);
        Task<int> UnsafeDeleteApp(int appId);
        Task<int> DeleteApp(int appId);
        //Task<int> UnsafeDeleteApp(int appId);
        Task<int> UpdateApp(ApplicationVM appVM);
        #endregion Application

        #region Category
        Task<List<CategoryVM>> GetCategories();
        Task<CategoryVM> GetCategoryById(int id);
        Task<int> CreateCategory(CategoryVM categoryVM);
        Task<int> DeleteCategory(int categoryVM);
        Task<int> UnsafeDeleteCategory(int categoryId);
        Task<int> UpdateCategory(CategoryVM categoryVM);
        #endregion Category    





        #region ApplicationRoles





        #endregion ApplicationRoles

    }
}