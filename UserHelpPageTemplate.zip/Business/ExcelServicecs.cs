﻿using DataLayer;
using DataLayer.Entities;
using Microsoft.EntityFrameworkCore;
using ClosedXML.Excel;
using System.Reflection;
using System.Runtime.InteropServices;
using ViewModels;

namespace UserHelpPageTemplate.Business
{

    public class ExcelService : IExcelService
    {
        private readonly IRepository _repo;
         

        public ExcelService(IRepository repo)
        {
            this._repo = repo;
        }

        public async Task PopulateDatabaseFromExcel(string filePath)
        {
            if (!_repo.GetApps().Any())
            {                            
                using var workbook = new XLWorkbook(filePath);
                var worksheet = workbook.Worksheet(1); // Assuming data is on the first sheet
                var rows = worksheet.RangeUsed().RowsUsed();

                // new db inst
                List<Application> applications = new List<Application>();

                foreach (var row in rows.Skip(1)) // Skip the header row
                {
                    var categoryName = row.Cell(7).Value.IsBlank ? "" : row.Cell(7).Value.GetText();

                    // Retrieve the Category object from the database based on the categoryName
                    var categories = _repo.GetCategories();

                    // Retrieve the Category object from the categories collection based on the categoryName
                    var category = categories.FirstOrDefault(x => x.Name == categoryName);

                    if (category == null)
                    {
                        // Category does not exist, create a new category and add it to the database
                        category = new Category
                        {
                            Name = categoryName,
                            Cloak = false,
                            CreatedBy = "import",
                            UpdatedBy = ""
                            // Set other properties as needed
                        };

                        // Add the new category to the Categories table
                        await _repo.AddItemAsync(category);
                    }
                    Console.WriteLine(row.Cell(1).Value.GetText());
                    var app = new Application()
                    {
                        
                        Name = row.Cell(1).Value.IsBlank ? "" : row.Cell(1).Value.GetText(),
                        ShortDescription = row.Cell(2).Value.IsBlank ? "" : row.Cell(2).Value.GetText(),
                        LongDescription = row.Cell(5).Value.IsBlank ? "" : row.Cell(5).Value.GetText(),
                        Modules = row.Cell(3).Value.IsBlank ? "" : row.Cell(3).Value.GetText(),
                        UserGroups = row.Cell(4).Value.IsBlank ? "" : row.Cell(4).Value.GetText(),
                        FAQ = row.Cell(6).Value.IsBlank ? "" : row.Cell(6).Value.GetText(),
                        CategoryId = category.Id, // Assign the ID of the category
                        PrimarySupportContact = row.Cell(8).Value.IsBlank ? "" : row.Cell(8).Value.GetText(),
                        SecondarySupportContact = row.Cell(9).Value.IsBlank ? "" : row.Cell(9).Value.GetText(),
                        Cloak = false,
                        CreatedBy = "import",
                        UpdatedBy = ""
                    };
                    applications.Add(app);
                }
               
                await _repo.AddItemsAsync(applications);
            }            
         
        }


        
    }
}

