﻿namespace UserHelpPageTemplate.Business
{
    public interface IExcelService
    {
        Task PopulateDatabaseFromExcel(string filePath);      
    }

}
