﻿using DataLayer.Entities;
using Microsoft.EntityFrameworkCore;
using System.Data;


namespace DataLayer
{
    public class UserHelpPageDbContext : DbContext
    {
        // constructor required to function currectly, also reference dbcontext
        public UserHelpPageDbContext(DbContextOptions<UserHelpPageDbContext> options) : base(options) { }
        //The DbSet<T> property is used to represent a table in the database as a collection of objects of type T.
        //For example, in your DbContext class (UserHelpPageDbContext), you have defined a DbSet<Application> property, 
        //which represents the "Apps" table in the database as a collection of Application objects.

        public DbSet<Application> Apps { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Log> Logs { get; set; }


    }
}
