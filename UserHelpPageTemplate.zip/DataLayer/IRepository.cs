﻿using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.EntityFrameworkCore;
using System.Data;
using DataLayer.Entities;
using Azure;
using System.Configuration;

namespace DataLayer
{
    //IRepository interface is generally an abstraction that allows you to define the contract for data access,
    public interface IRepository
    {

        //The IRepository interface defines the contract for the repository, which is responsible for handling data access operations.
        IQueryable<Application> GetApps(); //for example. getApps is expected to return an IQueryable<Application>    
        IQueryable<Category> GetCategories();
        IQueryable<Log> GetLogs();

        IDbContextTransaction GetDBTransaction();
        Task<int> AddItemAsync<T>(T entry);
        Task<int> AddItemsAsync<T>(List<T> entry);
        Task<int> UpdateItemAsync<T>(T entry);
        Task<int> UpdateItemsAsync<T>(List<T> entry);
        //Task<int> UpdateCloakValueAsync<T>(T entry, int cloakValue);
        Task<int> DeleteItemAsync<T>(T entry);
        Task<int> DeleteItemsAsync<T>(List<T> entry);
    }
}