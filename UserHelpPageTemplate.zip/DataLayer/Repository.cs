﻿using DataLayer.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System.Data;

namespace DataLayer
{
    //The Repository class implements the IRepository interface and provides the concrete implementation for the methods defined in the interface.
    public class Repository : IRepository
    {
        private readonly UserHelpPageDbContext _ctx;

        //This allows the Repository class to have access to the database context and perform data access operations.
        public Repository(UserHelpPageDbContext ctx)
        {
            _ctx = ctx;
        }

        public IQueryable<Application> GetApps()
        {
            //GetApps() method is implemented to return a filtered collection of Application objects.
            //It uses the Apps property of the _ctx(UserHelpPageDbContext)
            //to access the "Apps" table and applies a Where clause to filter the results based on a condition(x.Cloak == false).
            //The AsNoTracking() method is used to indicate that
            // the objects retrieved will not be tracked by the context,meaning they will not
            // be automatically updated in the database when changes are made to the objects.          
            return _ctx.Apps.Where(x => x.Cloak == false).AsNoTracking();
        }
        public IQueryable<Category> GetCategories()
        {
            return _ctx.Categories.Where(x => x.Cloak == false).AsNoTracking();
        }

        public IQueryable<Log> GetLogs()
        {
            return _ctx.Logs.AsNoTracking();
        }

        #region Generic
        private IDbContextTransaction _tran;
        public IDbContextTransaction GetDBTransaction()
        {
            if (_tran == null)
            {
                _tran = _ctx.Database.BeginTransaction(System.Data.IsolationLevel.Serializable);
            }
            else
            {
                if (_tran.GetDbTransaction().Connection == null)
                {
                    _tran = _ctx.Database.BeginTransaction(System.Data.IsolationLevel.Serializable);
                }
                else if (_tran.GetDbTransaction().Connection.State != ConnectionState.Open)
                {
                    _tran = _ctx.Database.BeginTransaction(System.Data.IsolationLevel.Serializable);
                }
            }
            return _tran;
        }

        public async Task<int> AddItemAsync<T>(T entry)
        {

            _ctx.Entry(entry).State = EntityState.Added;
            return await _ctx.SaveChangesAsync();

        }
        public async Task<int> AddItemsAsync<T>(List<T> entry)
        {

            foreach (var item in entry)
            {
                _ctx.Entry(item).State = EntityState.Added;
            }

            return await _ctx.SaveChangesAsync();

        }
        public async Task<int> UpdateItemAsync<T>(T entry)
        {
            _ctx.Entry(entry).State = EntityState.Modified;
            return await _ctx.SaveChangesAsync();
        }
        public async Task<int> UpdateItemsAsync<T>(List<T> entry)
        {
            foreach (var item in entry)
            {
                _ctx.Entry(item).State = EntityState.Modified;
            }
            return await _ctx.SaveChangesAsync();
        }
        //public async Task<int> UpdateCloakValueAsync<T>(T entry)
        //{
        //    if (entry is Application app)
        //    {
        //        app.Cloak = true;
        //        _ctx.Entry(app).State = EntityState.Modified;
        //        return await _ctx.SaveChangesAsync();
        //    }
        //    else
        //    {
        //        throw new ArgumentException("Invalid type for updating cloak value.", nameof(entry));
        //    }
        //}

        public async Task<int> DeleteItemAsync<T>(T entry)
        {
            _ctx.Entry(entry).State = EntityState.Deleted;
            return await _ctx.SaveChangesAsync();
        }

        public async Task<int> DeleteItemsAsync<T>(List<T> entry)
        {
            foreach (var item in entry)
            {
                _ctx.Entry(item).State = EntityState.Deleted;
            }
            return await _ctx.SaveChangesAsync();
        }

        #endregion
    }

}
