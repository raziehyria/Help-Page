﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Entities
{
    public class Log
    {
        public int Id { get; set; }
        public string Level { get; set; }
        public DateTime TimeStamp { get; set; }
        public string Exception { get; set; }
        public string UserId { get; set; }
        public string LogModule { get; set; }
        public string LogAction { get; set; }
        public string LogMessage { get; set; }
        public string CustomAttribute { get; set; }
        public string CustomAttributeValue { get; set; }
        public string CustomAttribute2 { get; set; }
        public string CustomAttributeValue2 { get; set; }



    }
}
