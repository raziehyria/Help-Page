﻿namespace DataLayer.Entities
{
    public class Application
    {
        public int Id { get; set; }
        // name set to empty, since its not nullable
        public string Name { get; set; } = string.Empty;
        // ? means nullable. since they dont require a value for. can be null in the database
        // allows for shorter syntex to check for null
        public string? ShortDescription { get; set; }
        public string? LongDescription { get; set; }
        public string? Modules { get; set; }
        // change usergroups to seperate table and link through listof
        public string? UserGroups { get; set; }
        public string? FAQ { get; set; }      
        public string? PrimarySupportContact { get; set; }
        public string? SecondarySupportContact { get; set; }
        public bool Cloak { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public int? CategoryId { get; set; }
        public virtual Category? Category { get; set; }
    }
}
