﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace AppLogger
{
    public class UserHelpPageLogger : IUserHelpPageLogger
    {
        private readonly ILogger<UserHelpPageLogger> logger;

        private readonly string currentUser;
        public UserHelpPageLogger(ILogger<UserHelpPageLogger> logger, IHttpContextAccessor httpContext)
        {
            this.logger = logger;
            currentUser = httpContext?.HttpContext?.User?.Identity?.Name ?? "undefined";
        }

        public void LogMessage(LogLevel logLevel, string module, string action, string message, string customAttribute, string customAttributeValue, Exception exception = null, string userId = "")
        {
            var user = string.IsNullOrEmpty(userId) ? currentUser : userId;
            if (exception == null)
            {
                logger.Log(logLevel, "{UserId} {LogModule} {LogAction} {LogMessage} {CustomAttribute} {CustomAttributeValue}",
                    user, module, action, message, customAttribute, customAttributeValue);
            }
            else
            {
                logger.LogError(exception, "{UserId} {LogModule} {LogAction} {LogMessage} {CustomAttribute} {CustomAttributeValue}",
                   user, module, action, message, customAttribute, customAttributeValue);
            }

        }
        public void LogMessage(LogLevel logLevel, string module, string action, string message, string customAttribute, string customAttributeValue, string customAttribute2, string customAttributeValue2, Exception exception = null, string userId = "")
        {



            var user = string.IsNullOrEmpty(userId) ? currentUser : userId;



            if (exception == null)
            {
                logger.Log(logLevel, "{UserId} {LogModule} {LogAction} {LogMessage} {CustomAttribute} {CustomAttributeValue} {CustomAttribute2} {CustomAttributeValue2}",
                    user, module, action, message, customAttribute, customAttributeValue, customAttribute2, customAttributeValue2);
            }
            else
            {
                logger.LogError(exception, "{UserId} {LogModule} {LogAction} {LogMessage} {CustomAttribute} {CustomAttributeValue} {CustomAttribute2} {CustomAttributeValue2}",
                   user, module, action, message, customAttribute, customAttributeValue, customAttribute2, customAttributeValue2);
            }



        }
    }
}
