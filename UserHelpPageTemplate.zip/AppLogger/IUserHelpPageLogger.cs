﻿using Microsoft.Extensions.Logging;

namespace AppLogger
{
    public interface IUserHelpPageLogger
    {
        void LogMessage(LogLevel logLevel, string module, string action, string message, string customAttribute, string customAttributeValue, Exception exception = null, string userId = "");
        void LogMessage(LogLevel logLevel, string module, string action, string message, string customAttribute, string customAttributeValue, string customAttribute2, string customAttributeValue2, Exception exception = null, string userId = "");
    }
}